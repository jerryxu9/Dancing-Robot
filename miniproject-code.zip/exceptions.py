class ServoNotConnected(Exception):
	pass

class MustBeOfTypeNote(Exception):
	pass