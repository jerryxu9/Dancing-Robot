class Logger():
	LOG = None#logging.getLogger("biped")
	#logging.basicConfig(format='%(name)s:%(module)s %(levelname)s: %(message)s',
     #                   datefmt='%m/%d/%Y %I:%M:%S %p', level=logging.INFO)  
	